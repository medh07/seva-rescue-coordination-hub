# ResQ-Flow connection milestone 1

This patch adds a separate browser Supabase client for the existing ResQ-Flow
project and a login/access screen around the existing app. No database migration
is included. It does not alter Lovable Cloud settings or service-role credentials.

## What works in this patch
- Email/password sign-in to ResQ-Flow, persistent session, local sign-out.
- Reads the user's active roles from public.user_roles.
- Only active admin/officer accounts get the command-centre request screen.
- Reads public.requests under the signed-in user's RLS permissions, 50 per page.
- Shows reported severity, officer priority, verification and status separately.
- Manual Refresh, error, empty and denied states. No demo fallback on errors.
- Existing UI remains available to approved users via Open original demo. A
  persistent banner explains that its buttons only affect simulated local data.

## What is NOT connected yet
Assignment, status/verification changes, shelters, resources, alerts, maps,
photos, realtime subscriptions, citizen app and phone OTP remain future work.
This first screen reads requests only. It is not a production emergency system.

## Install (GitHub)
The files/ directory in the patch ZIP contains only five changed/new files.
Copy its contents into the repository ROOT, preserving their src/ paths.
Do not upload the ZIP itself or replace the repository with an extra folder.
No package.json, lockfile, SQL, environment file or secret changes are required.
Commit to the branch Lovable syncs (currently main), then inspect Lovable preview.
Publishing the updated website is a separate step after testing.

## First check
Sign in using the account created in the ResQ-Flow Supabase Authentication panel.
If you see 'officer access pending', login worked but no approved role exists.
Do NOT disable RLS or add a role selector. Grant the intended role separately
through the trusted Supabase console. Officers also require area scopes.
The existing guarded first-admin script is a separate step; do not run the full
backend installation again. We will handle the account setup together.

If the account is unconfirmed, confirm your own test account through the trusted
Supabase user administration screen. This code does not disable confirmations.

The public URL and publishable key supplied by the project owner are in
src/lib/resq/client.ts. These are frontend credentials, not service secrets.
No passwords or secret/service-role keys are included.

## Validation
See CHECKS.txt for the actual checks completed and remaining hosted checks.
The original routing test remains valid; access tests exercise the new gate.

## Rollback
Restore src/routes/__root.tsx from its previous GitHub commit. The added files
are then unused. This patch changes no data or database configuration.
